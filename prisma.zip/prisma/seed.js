const { PrismaClient } = require('@prisma/client')

const prisma = new PrismaClient()

const teams = [
  {
    name: "Team Ganga",
    captain: "Sowmiya Thangaraj", 
    viceCaptain: "Ganesh",
    color: "Pink"
  },
  {
    name: "Team Yamuna",
    captain: "Lokesh",
    viceCaptain: "Snega S", 
    color: "Black"
  },
  {
    name: "Team Kaveri",
    captain: "Akash",
    viceCaptain: "Sri Kaviya",
    color: "Red"  
  },
  {
    name: "Team Vaigai",
    captain: "Akhil",
    viceCaptain: "Pavadharani",
    color: "Yellow"
  }
]

const games = [
  { name: "Carrom", type: "Team vs Team", category: "INDOOR", icon: "🎯" },
  { name: "Volley Ball", type: "Men & Women", category: "OUTDOOR", icon: "🏐" },
  { name: "Throw Ball", type: "Men & Women", category: "OUTDOOR", icon: "⚽" },
  { name: "Koko", type: "Men & Women", category: "OUTDOOR", icon: "🥎" },
  { name: "Tennikoit", type: "Women", category: "OUTDOOR", icon: "🎾" },
  { name: "100m Sprint", type: "Men & Women", category: "TRACK", icon: "🏃" },
  { name: "200m Sprint", type: "Men & Women", category: "TRACK", icon: "🏃‍♀️" },
  { name: "Relay Race (4x100m)", type: "Men & Women", category: "TRACK", icon: "🏃‍♂️" },
  { name: "Shot Put", type: "Men & Women", category: "FIELD", icon: "🏋️" },
  { name: "Long Jump", type: "Men & Women", category: "FIELD", icon: "🤸" },
  { name: "Lemon in the Spoon", type: "Men & Women", category: "FUN", icon: "🍋" }
]

async function main() {
  console.log('Start seeding...')

  // Clear existing data
  await prisma.vote.deleteMany()
  await prisma.match.deleteMany() 
  await prisma.user.deleteMany()
  await prisma.game.deleteMany()
  await prisma.team.deleteMany()

  // Seed teams
  for (const team of teams) {
    await prisma.team.create({
      data: team
    })
  }

  // Seed games  
  for (const game of games) {
    await prisma.game.create({
      data: game
    })
  }

  // Create admin user
  await prisma.user.create({
    data: {
      secretCode: 'ADMIN2025',
      role: 'ADMIN'
    }
  })

  // Create user codes
  for (let i = 1; i <= 25; i++) {
    await prisma.user.create({
      data: {
        secretCode: `USER${i.toString().padStart(3, '0')}`,
        role: 'USER'
      }
    })
  }

  console.log('Seeding finished.')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })
