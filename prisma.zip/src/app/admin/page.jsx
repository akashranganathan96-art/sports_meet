import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { verifyToken } from '@/lib/auth'
import AdminKanbanBoard from '@/components/AdminKanbanBoard'
import Leaderboard from '@/components/Leaderboard'
import Header from '@/components/Header'

export default async function AdminPage() {
  const cookieStore = cookies()
  const token = cookieStore.get('auth-token')?.value

  if (!token) {
    redirect('/login')
  }

  const user = verifyToken(token)
  if (!user || user.role !== 'ADMIN') {
    redirect('/login')
  }

  return (
    <div className="min-h-screen">
      <Header user={user} />
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 p-6">
        <div className="xl:col-span-3">
          <AdminKanbanBoard user={user} />
        </div>
        <div className="xl:col-span-1">
          <Leaderboard />
        </div>
      </div>
    </div>
  )
}
