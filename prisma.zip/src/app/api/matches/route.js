const { NextResponse } = require('next/server')
const { prisma } = require('@/lib/db')
const { verifyToken, isAdmin } = require('@/lib/auth')
const { generateRandomPairs } = require('@/lib/utils')

async function GET() {
  try {
    const matches = await prisma.match.findMany({
      include: {
        game: {
          select: {
            name: true,
            type: true,
            icon: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(matches)
  } catch (error) {
    console.error('Get matches error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch matches' },
      { status: 500 }
    )
  }
}

async function POST(request) {
  try {
    const token = request.cookies.get('auth-token')?.value
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = verifyToken(token)
    if (!user || !isAdmin(user)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const { gameId } = await request.json()

    // Get all users who voted for this game
    const votes = await prisma.vote.findMany({
      where: { gameId },
      include: {
        user: {
          select: {
            secretCode: true
          }
        }
      }
    })

    if (votes.length < 2) {
      return NextResponse.json(
        { error: 'Not enough participants for this game' },
        { status: 400 }
      )
    }

    const participants = votes.map(vote => vote.user.secretCode)
    const pairs = generateRandomPairs(participants)

    // Create matches
    const matchPromises = pairs.map(pair => 
      prisma.match.create({
        data: {
          gameId,
          player1: pair.player1,
          player2: pair.player2,
          scheduledAt: new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000) // Random date in next 7 days
        }
      })
    )

    const matches = await Promise.all(matchPromises)

    return NextResponse.json({ 
      message: 'Matches scheduled successfully',
      matches: matches.length,
      pairs
    })
  } catch (error) {
    console.error('Create matches error:', error)
    return NextResponse.json(
      { error: 'Failed to schedule matches' },
      { status: 500 }
    )
  }
}

module.exports = { GET, POST }
