const { NextResponse } = require('next/server')
const { prisma } = require('@/lib/db')

async function GET() {
  try {
    // Get vote counts by user
    const voteCounts = await prisma.vote.groupBy({
      by: ['userId'],
      _count: {
        userId: true
      },
      orderBy: {
        _count: {
          userId: 'desc'
        }
      }
    })

    // Get match win counts
    const matchWins = await prisma.match.groupBy({
      by: ['result'],
      where: {
        result: {
          not: null
        }
      },
      _count: {
        result: true
      }
    })

    // Get user details
    const users = await prisma.user.findMany({
      where: {
        role: 'USER'
      },
      select: {
        id: true,
        secretCode: true
      }
    })

    // Combine data for leaderboard
    const leaderboard = users.map(user => {
      const voteCount = voteCounts.find(vc => vc.userId === user.id)?._count.userId || 0
      const winCount = matchWins.find(mw => mw.result === user.secretCode)?._count.result || 0
      
      return {
        userId: user.id,
        secretCode: user.secretCode,
        votesCount: voteCount,
        winsCount: winCount,
        totalScore: (voteCount * 10) + (winCount * 50) // Simple scoring system
      }
    }).sort((a, b) => b.totalScore - a.totalScore)

    return NextResponse.json(leaderboard)
  } catch (error) {
    console.error('Get leaderboard error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch leaderboard' },
      { status: 500 }
    )
  }
}

module.exports = { GET }
